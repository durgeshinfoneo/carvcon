import React from 'react';

const NotFoundPage = () => (
  <div className="row">
    <div className="content">
      <h1>Page Not Found! </h1>
    </div>
  </div>
);

export default NotFoundPage;
